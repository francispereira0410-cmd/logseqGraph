# London Loop

![](https://readwise-assets.s3.amazonaws.com/media/reader/parsed_document_assets/419995869/QgfWBmDIxDxqRo4P8Yi_a0JN4Efxe_KSsHVLNjo1aos-cove_znDSVcY.png)

### Metadata

- Author: Transport for London
- Full Title: London Loop
- Category: #articles
- Summary: This London LOOP walk is a short, easy route through green woodland and farmland from Moor Park to Hatch End stations. You will see nature reserves, charming cottages, and the historic Pinnerwood House. Facilities include public toilets, pubs, and cafes at the start and end.
- URL: https://readwise.io/reader/document_raw_content/419995869

### Highlights

- This is an easy walking, very green and quite short LOOP section through woodland with little road- walking. It crosses farmland around the community of Pinnerwood, where you walk between charming cottages with well-kept ponds and lawns. ([View Highlight](https://read.readwise.io/read/01kh81v5dfcj4n2617v4gwcn66))
