# BMA Fatigue and Facilities Charter

![](https://readwise-assets.s3.amazonaws.com/media/reader/parsed_document_assets/339444405/EQ-bjbUIJNaVHLTAhDE9K9D3Cn9TtrLlrebzamithH0-cove_8Zk0iBz.png)

### Metadata

- Author: British Medical Association
- Full Title: BMA Fatigue and Facilities Charter
- Category: #articles
- Summary: The BMA Fatigue and Facilities Charter aims to improve doctors' working conditions by reducing fatigue and providing better rest facilities. It sets clear standards for shift planning, breaks, rest areas, catering, and safe travel. Employers are encouraged to follow these guidelines to support doctors' health and patient safety.
- URL: https://readwise.io/reader/document_raw_content/339444405

### Highlights

- – When designing rotas, refer to joint guidance from NHS Employers or equivalent and the BMA, where available. ([View Highlight](https://read.readwise.io/read/01kh51dk5sb64b9xgp5w91e0sz))
- At induction, provide basic education on sleep and working nights, as ([View Highlight](https://read.readwise.io/read/01kh54sr338yas3fv1by9080vm))
