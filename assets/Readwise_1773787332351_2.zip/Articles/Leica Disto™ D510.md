# Leica Disto™ D510

![](https://readwise-assets.s3.amazonaws.com/media/reader/parsed_document_assets/419609966/VBvd3zKfTofC8KBToAKgmCv0WrwVctarqRWuivt1-OA-cove_c43de45.png)

### Metadata

- Author: Leica Geosystems
- Full Title: Leica Disto™ D510
- Category: #articles
- URL: https://readwise.io/reader/document_raw_content/419609966

### Highlights

- Message Codes - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 5 ([View Highlight](https://read.readwise.io/read/01kh5s7fe7k11dhgf411gamb6c))
