# Getting Started with Reader

![](https://s3.amazonaws.com/readwiseio/2022/08/i-give-you-reader-1.png)

### Metadata

- Author: Daniel Doyon
- Full Title: Getting Started with Reader
- Category: #articles
- Summary: Reader is a powerful app that helps you save, highlight, and organize all kinds of reading materials in one place. You can use keyboard shortcuts, browser extensions, and mobile apps to read, annotate, and listen to content easily. The app keeps improving every day based on user feedback to make reading and learning better.
- URL: https://blog.readwise.io/p/bf87944f-b0fe-4f08-a461-f75ab8aded6a/

### Highlights

- Think of the Library section as your permanent archive of digital documents: a place of high signal and lo ([View Highlight](https://read.readwise.io/read/01kh687m5smvk2yj79y6j72d16))
